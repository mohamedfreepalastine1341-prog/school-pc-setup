SCHOOL PC REMOTE SETUP
=======================

This package is for an authorized Windows 10 school PC.

WHAT IT SETS UP
- Windows Remote Desktop (RDP), if the Windows edition can host it
- Network Level Authentication
- Windows Remote Desktop firewall rules
- Wake-on-Magic-Packet settings for network adapters where Windows supports them
- A desktop text file containing the computer name, current IP addresses, and MAC addresses

WHAT IT CANNOT DO
- It cannot change BIOS/UEFI settings automatically.
- It cannot make a powered-off PC reachable by RDP by itself.
- Wake-on-LAN over the Internet normally needs a VPN, router support, or a device already on the school LAN.
- It does not bypass school firewall/network policy.
- Do not expose RDP port 3389 directly to the public Internet.

HOW TO RUN
1. Copy SchoolPC_Setup.ps1 to the school Windows 10 PC.
2. Right-click it.
3. Choose "Run with PowerShell" (or open PowerShell as Administrator and run it).
4. Follow the on-screen messages.
5. If Windows says the file is blocked, use the file Properties > Unblock if that option is present.

WINDOWS EDITION
Windows 10 Pro, Enterprise, and Education can host incoming Microsoft Remote Desktop.
Windows 10 Home cannot host incoming RDP.

IMPORTANT
You must have authorization to administer the PC and the network.
