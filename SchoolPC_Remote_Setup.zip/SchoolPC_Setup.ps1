# School PC Authorized Remote Setup
# Run this file AS ADMINISTRATOR on the Windows 10 school PC.
# It configures Windows Remote Desktop (RDP), its firewall rules,
# and Wake-on-LAN adapter settings where Windows exposes them.
# It does NOT bypass school/network restrictions or configure BIOS firmware.

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "============================================="
Write-Host "   AUTHORIZED SCHOOL PC REMOTE SETUP"
Write-Host "============================================="
Write-Host ""

# Require Administrator
$principal = New-Object Security.Principal.WindowsPrincipal(
    [Security.Principal.WindowsIdentity]::GetCurrent()
)
if (-not $principal.IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator
)) {
    Write-Host "ERROR: Right-click this file and choose 'Run with PowerShell' as Administrator."
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "[1/5] Checking Windows edition..."
$edition = (Get-CimInstance Win32_OperatingSystem).Caption
Write-Host "Detected: $edition"

if ($edition -match "Home") {
    Write-Host ""
    Write-Host "Windows Home cannot host incoming Microsoft Remote Desktop (RDP)."
    Write-Host "The setup will stop before changing RDP settings."
    Write-Host ""
    Write-Host "If the PC is Windows 10 Pro/Education/Enterprise, run this again there."
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "[2/5] Enabling Remote Desktop..."
Set-ItemProperty `
    -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server" `
    -Name "fDenyTSConnections" `
    -Type DWord `
    -Value 0

# Require Network Level Authentication.
Set-ItemProperty `
    -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" `
    -Name "UserAuthentication" `
    -Type DWord `
    -Value 1

Write-Host "[3/5] Enabling Windows Remote Desktop firewall rules..."
Enable-NetFirewallRule -DisplayGroup "Remote Desktop" -ErrorAction SilentlyContinue

Write-Host "[4/5] Configuring Wake-on-LAN where supported..."
$adapters = Get-NetAdapter -Physical -ErrorAction SilentlyContinue

foreach ($adapter in $adapters) {
    try {
        Set-NetAdapterPowerManagement `
            -Name $adapter.Name `
            -WakeOnMagicPacket Enabled `
            -ErrorAction Stop | Out-Null

        Write-Host "  Wake-on-Magic-Packet enabled: $($adapter.Name)"
    }
    catch {
        Write-Host "  Could not configure Wake-on-LAN on: $($adapter.Name)"
    }
}

Write-Host "[5/5] Saving connection information..."
$infoPath = "$env:PUBLIC\Desktop\School PC Remote Info.txt"

$computer = $env:COMPUTERNAME
$ips = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
    Where-Object {
        $_.IPAddress -notmatch '^127\.' -and
        $_.IPAddress -notmatch '^169\.254\.'
    } |
    Select-Object -ExpandProperty IPAddress

$macs = Get-NetAdapter -Physical -ErrorAction SilentlyContinue |
    Select-Object Name, MacAddress, Status

@"
AUTHORIZED REMOTE ACCESS
========================

Computer name:
$computer

Windows edition:
$edition

IPv4 addresses currently detected:
$($ips -join "`r`n")

Network adapters / MAC addresses:
$($macs | Out-String)

Remote Desktop:
Enabled
Network Level Authentication:
Enabled

IMPORTANT:
- The school PC must be powered on for RDP.
- Wake-on-LAN normally requires BIOS/UEFI support and the PC to remain connected to power/network.
- Remote Wake-on-LAN across the Internet usually requires a VPN/router feature or another device on the same LAN.
- Do not expose TCP 3389 directly to the public Internet.
- Only use this setup on a PC/network you are authorized to administer.
"@ | Set-Content -Path $infoPath -Encoding UTF8

Write-Host ""
Write-Host "============================================="
Write-Host "SETUP COMPLETE"
Write-Host "============================================="
Write-Host ""
Write-Host "Remote Desktop is enabled."
Write-Host "A file was placed on the Public Desktop:"
Write-Host "  $infoPath"
Write-Host ""
Write-Host "NEXT:"
Write-Host "1. At school, test RDP from another PC on the same network."
Write-Host "2. Enter the school PC's computer name/IP in Remote Desktop."
Write-Host "3. Use a Windows account authorized to sign in remotely."
Write-Host "4. For Wake-on-LAN, enable Wake-on-LAN in BIOS/UEFI if required."
Write-Host "5. For home-to-school access, use an administrator-approved VPN/private network."
Write-Host ""
Read-Host "Press Enter to close"
